/**
 * Launch Request Handler
 * Triggered when user says "Alexa, open Ganamos"
 */
import { RequestHandler } from 'ask-sdk-core';
export declare const LaunchHandler: RequestHandler;
//# sourceMappingURL=LaunchHandler.d.ts.map