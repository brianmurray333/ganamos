/**
 * Balance Intent Handler
 * Handles requests to check user's sat balance
 */
import { RequestHandler } from 'ask-sdk-core';
export declare const BalanceHandler: RequestHandler;
//# sourceMappingURL=BalanceHandler.d.ts.map